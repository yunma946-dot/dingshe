#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path


START = "/* HQ_SITE1_SHARP_BUTTON_START */"
END = "/* HQ_SITE1_SHARP_BUTTON_END */"
BLOCK = r'''/* HQ_SITE1_SHARP_BUTTON_START */
        .hq-btn:not(.open){
          background-image:url("${origin}/assets/site1_widget_brand_button.svg?v=20260926c")!important;
          background-repeat:no-repeat!important;
          background-position:center!important;
          background-size:100% 100%!important;
          image-rendering:auto!important;
        }
        .hq-btn.open{
          width:58px!important;
          height:58px!important;
          background-image:none!important;
        }
        /* HQ_SITE1_SHARP_BUTTON_END */'''


def main() -> int:
    if len(sys.argv) != 2:
        print("用法：patch_widget.py /var/www/chat/widget.js")
        return 2

    path = Path(sys.argv[1])
    text = path.read_text(encoding="utf-8")

    marker_pattern = re.compile(re.escape(START) + r".*?" + re.escape(END), re.S)
    if marker_pattern.search(text):
        updated = marker_pattern.sub(BLOCK, text, count=1)
    else:
        anchor_pattern = re.compile(r"background-size\s*:\s*235px\s+93px\s*;")
        match = anchor_pattern.search(text)
        if not match:
            print("错误：未找到前台1低清按钮样式，未修改 widget.js。")
            return 1
        updated = text[: match.end()] + "\n        " + BLOCK + text[match.end() :]

    if START not in updated or "site1_widget_brand_button.svg?v=20260926c" not in updated:
        print("错误：高清按钮补丁校验失败，未保存。")
        return 1

    path.write_text(updated, encoding="utf-8", newline="\n")
    print("widget.js 高清SVG按钮补丁已写入。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
